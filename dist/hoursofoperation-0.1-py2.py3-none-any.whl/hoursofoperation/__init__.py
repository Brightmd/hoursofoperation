"""
Utilities for loading and doing calculations with a partner's hours of
operations configration.
"""